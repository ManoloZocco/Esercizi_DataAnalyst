Gentilissimi,

con il CapStone Project non mi sono focalizzato tanto sulla realizzazione di una DashBoard di PowerBi completa di tutte le funzionalità e i metodi appresi durante il corso, quanto sulla scrittura query SQL "complesse"  – volte a realizzare piccoli dataset specifici per ogni pagina del Report – e sull'utilizzo di Pandas.
In tal senso, ho sfruttato librerie e moduli di Python tramite i quali ho potuto allenare un algoritmo di Machine Learning in grado di effettuare una previsione di vendita per i 4 trimestri successivi ai dati forniti dal database sql utilizzato.

Per completezza, nelle varie cartelle ho lasciato tutte le query SQL e i file utilizzati e/o esportati dai software che ho sfruttato.