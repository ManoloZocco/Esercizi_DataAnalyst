SELECT 
    orderDate AS dataOrdine, 
    SUM(quantityOrdered * priceEach) AS Totale
FROM 
    orders
JOIN 
    orderdetails ON orders.orderNumber = orderdetails.orderNumber
GROUP BY 
    orderDate 
ORDER BY 
    orderDate;