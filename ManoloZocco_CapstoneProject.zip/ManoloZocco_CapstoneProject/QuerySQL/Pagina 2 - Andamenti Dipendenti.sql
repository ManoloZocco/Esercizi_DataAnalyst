SELECT 
    e.employeeNumber AS NumeroDipendente,
    e.firstName AS NomeDipendente,
    e.lastName AS CognomeDipendente,
    o.orderDate AS DataOrdine,
    SUM(od.quantityOrdered * od.priceEach) AS TotaleVendite
FROM employees e
JOIN customers c ON e.employeeNumber = c.salesRepEmployeeNumber
JOIN orders o ON c.customerNumber = o.customerNumber
JOIN orderdetails od ON o.orderNumber = od.orderNumber
GROUP BY 
    e.employeeNumber,
    e.firstName,
    e.lastName,
    o.orderDate
ORDER BY 
    e.employeeNumber,
    o.orderDate;
