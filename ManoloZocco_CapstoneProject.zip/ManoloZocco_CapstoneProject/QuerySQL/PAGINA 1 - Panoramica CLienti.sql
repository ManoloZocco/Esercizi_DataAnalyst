SELECT 
    c.customerNumber AS NumeroCliente,
    c.customerName AS NomeCliente,
    c.country AS Paese,
    c.city AS Città,
    (SELECT COUNT(*) FROM customers) AS NumeroTotaleClienti,
    SUM(od.quantityOrdered * od.priceEach) AS FatturatoCliente,
    CASE 
        WHEN SUM(od.quantityOrdered * od.priceEach) < 50000 THEN 'Basso'
        WHEN SUM(od.quantityOrdered * od.priceEach) BETWEEN 50000 AND 100000 THEN 'Medio'
        ELSE 'Alto'
    END AS CategoriaSpesa
FROM 
    customers c
LEFT JOIN 
    orders o ON c.customerNumber = o.customerNumber
LEFT JOIN 
    orderdetails od ON o.orderNumber = od.orderNumber
GROUP BY 
    c.customerNumber, c.customerName, c.country, c.city;
