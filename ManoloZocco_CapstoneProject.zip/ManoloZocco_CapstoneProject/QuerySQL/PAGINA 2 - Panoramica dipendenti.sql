SELECT 
    e.employeeNumber AS Numero_Dipendente,
    e.lastName AS Cognome,
    e.firstName AS Nome,
    e.extension AS Telefono,
    e.email AS Email,
    e.officeCode AS Codice_Ufficio,
    e.reportsTo AS Fa_Report_A,
    e.jobTitle AS Titolo_Lavorativo,
    COUNT(DISTINCT o.orderNumber) AS Numero_Vendite,
    SUM(od.quantityOrdered * od.priceEach) AS Fatturato
FROM 
    employees e
LEFT JOIN 
    customers c ON e.employeeNumber = c.salesRepEmployeeNumber
LEFT JOIN 
    orders o ON c.customerNumber = o.customerNumber
LEFT JOIN 
    orderdetails od ON o.orderNumber = od.orderNumber
GROUP BY 
    e.employeeNumber
ORDER BY 
    Fatturato DESC;
