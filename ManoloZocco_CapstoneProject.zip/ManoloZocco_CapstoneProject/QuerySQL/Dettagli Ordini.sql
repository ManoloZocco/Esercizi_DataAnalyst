SELECT 
    o.orderNumber AS NumeroOrdine,
    o.orderDate AS DataOrdine,
    o.requiredDate AS DataRichiesta,
    o.shippedDate AS DataSpedizione,
    o.status AS Stato,
    o.comments AS Commenti,
    c.customerNumber AS NumeroCliente,
    c.customerName AS NomeCliente,
    od.productCode AS CodiceProdotto,
    p.productName AS NomeProdotto,
    pl.productLine AS CategoriaProdotto,
    od.quantityOrdered AS QuantitaOrdinata,
    od.priceEach AS PrezzoUnitario,
    od.orderLineNumber AS NumeroLineaOrdine,
    (od.quantityOrdered * od.priceEach) AS TotaleProdotto,
    (od.quantityOrdered * (od.priceEach - p.buyPrice)) AS MargineProfitto
FROM 
    orders o
JOIN 
    orderdetails od ON o.orderNumber = od.orderNumber
JOIN 
    customers c ON o.customerNumber = c.customerNumber
JOIN 
    products p ON od.productCode = p.productCode
JOIN
    productlines pl ON p.productLine = pl.productLine
ORDER BY
    o.orderNumber,
    od.orderLineNumber;
