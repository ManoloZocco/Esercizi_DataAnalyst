SELECT 
    p.productCode AS CodiceProdotto,
    p.productName AS NomeProdotto,
    p.productLine AS CategoriaProdotto,
    COUNT(od.orderNumber) AS NumeroVendite,
    SUM(od.quantityOrdered) AS QuantitàTotaleVenduta,
    SUM(od.quantityOrdered * od.priceEach) AS FatturatoTotale,
    (SUM(od.quantityOrdered * od.priceEach) - (p.buyPrice * SUM(od.quantityOrdered))) AS MargineDiProfitto
FROM 
    products p
LEFT JOIN 
    orderdetails od ON p.productCode = od.productCode
GROUP BY 
    p.productCode, p.productName, p.productLine, p.buyPrice
ORDER BY 
    NumeroVendite DESC, FatturatoTotale DESC;
