SELECT 
    customerNumber AS NumeroCliente,
    customerName AS NomeCliente,
    contactLastName AS CognomeContatto,
    contactFirstName AS NomeContatto,
    country AS Paese,
    city AS Citta,
    addressLine1 AS Indirizzo1,
    addressLine2 AS Indirizzo2,
    state AS Stato,
    postalCode AS CodicePostale,
    phone AS Telefono,
    salesRepEmployeeNumber AS NumeroRappresentanteVendite
FROM 
    customers;
