SELECT 
    o.orderDate AS dataOrdine,
    pl.productLine AS Linea,
    SUM(od.quantityOrdered * od.priceEach) AS Totale
FROM 
    orders o
JOIN 
    orderdetails od ON o.orderNumber = od.orderNumber
JOIN 
    products p ON od.productCode = p.productCode
JOIN 
    productlines pl ON p.productLine = pl.productLine
GROUP BY 
    o.orderDate, pl.productLine
ORDER BY 
    o.orderDate;
